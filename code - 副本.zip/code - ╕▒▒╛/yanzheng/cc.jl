using DelimitedFiles, WriteVTK ,BenchmarkTools
push!(LOAD_PATH,"./module")
using DT_bushing
using Distributed
# addprocs()
@everywhere push!(LOAD_PATH,"./module")
@everywhere using FOSFEM,LinearAlgebra
# node=[0 2 0;2.0 0 0;1 0 1;0 0 2;0 0 0]

# element=[1 3 4 5;1 2 3 5]
# nele=size(element,1)
# element=sort(element,dims=2)
# SD=FOSFEM.GetSDofNode(node,element)
# ##
# v=0
# for i=1:size(SD,5)
#     for j=1:4
#         v=v+SD[4,1,4,j,i]
#     end
# end
# v
##
pos="./data/QUAD"
node = readdlm(string(pos, "/node.txt"), Float64)[:,2:4]
element=readdlm(string(pos,"/element.txt"),Int64)[:,[12,13,15,18]]
MATID=readdlm(string(pos,"/element.txt"),Int64)[:,1]
BDY1 = readdlm(string(pos, "/BDYZR1.txt"), Int64)[:, 6:9]
BDY2 = readdlm(string(pos, "/BDYZR2.txt"), Int64)[:, 6:9]
SD=FOSFEM.GetSDofNode(node,element)
##
MAT=[1 1;2 2]
KV,KT,HD=FOSFEM.GetCellSDMatrix(SD, element, MAT, MATID)
##
F=zeros(size(K,1))
##
dof=unique(BDY1[:])
value=10
for i in dof
    K[i,:].=0
    K[i,i]=1
    F[i]=value
end

dof=unique(BDY2[:])
value=0
for i in dof
    K[i,:].=0
    K[i,i]=1
    F[i]=value
end
##
u=K\F
##
FOSFEM.writeResulttovtk_TET(node, element,r=u)
##

function GetJoulSource(node,element,HD,SD)
    QJ=zeros(size(node,1))

    for i=1:size(element,1)
        uele=u[element[i,:]]
        h=zeros(4)
        for j=1:4
            dof=setdiff(1:4,j)
            v=SD[4,1,4,j,i]
            B=HD[:,:,j,i]/v
            E=B*uele
            qj=dot(E,C[2]*E)

            ih=v/4
            
            h[dof[1]]+=ih[1]*1.25*qj
            h[dof[2]]+=ih[1]*1.25*qj
            h[dof[3]]+=ih[1]*1.25*qj
            h[j]+=ih[1]*0.25*qj
        end
    
        a=element[i,:]
        for k=1:4
            QJ[a[k]]+=h[k]
        end
    end

    return QJ
end




##
jelehex= readdlm(string(pos, "/element.txt"), Int64)[:, push!(collect(12:19), 1)]
@time FJ = DT_bushing.TGetelemat(node,elehex , [1 1 1;1 1 1], u)
##
norm(FJ-QJ)