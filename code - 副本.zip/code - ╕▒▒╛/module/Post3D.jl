module Post3D

using WriteVTK ,LinearAlgebra
export writeResulttovtk,writegridHex,writegridTet,write2Dgrid2VTK,MutiwriteResulttovtk

function writeResulttovtk(Result, node, element,name::String,des::String)
    cells = MeshCell[]
    for i = 1:size(element, 1)
        a = MeshCell(VTKCellType(12), element[i,:])
        push!(cells, a)
    end
    vtkfile = vtk_grid(name, node[:,1], node[:,2], node[:,3], cells)
    vtkfile[des, VTKPointData()] = Result
    outfiles = vtk_save(vtkfile)
end

function MutiwriteResulttovtk(Result1,Result2, node, element,name::String,des::String,des2::String)
    cells = MeshCell[]
    for i = 1:size(element, 1)
        a = MeshCell(VTKCellType(12), element[i,:])
        push!(cells, a)
    end
    vtkfile = vtk_grid(name, node[:,1], node[:,2], node[:,3], cells)
    vtkfile[des, VTKPointData()] = Result1
    vtkfile[des2, VTKPointData()] = Result2
    outfiles = vtk_save(vtkfile)
end

function writegridHex(node, element,name::String)
    cells = MeshCell[]
    for i = 1:size(element, 1)
        a = MeshCell(VTKCellType(12), element[i,:])
        push!(cells, a)
    end
    vtkfile = vtk_grid(name, node[:,1], node[:,2], node[:,3], cells)
    outfiles = vtk_save(vtkfile)
end

function writegridTet(node, element,name::String)
    cells = MeshCell[]
    for i = 1:size(element, 1)
        a = MeshCell(VTKCellType(10), element[i,:])
        push!(cells, a)
    end
    vtkfile = vtk_grid(name, node[:,1], node[:,2], node[:,3], cells)
    outfiles = vtk_save(vtkfile)
end

function write2Dgrid2VTK(node, element,name::String)
    if size(element,2)==4
        style=9
    elseif size(element,2)==3
        style=5
    elseif size(element,2)==6
        style=22
    end
    cells = MeshCell[]
    for i = 1:size(element, 1)
        a = MeshCell(VTKCellType(style), element[i,:])
        push!(cells, a)
    end
    vtkfile = vtk_grid(name, node[:,1], node[:,2],  cells)
    outfiles = vtk_save(vtkfile)
end

function Error(A,B)
    out=(norm(A-B)/norm(A))
    return log10(out)
end

end