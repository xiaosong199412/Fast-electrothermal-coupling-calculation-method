module FOSFEM
using CUDA, SparseArrays, SharedArrays, Distributed, Pardiso, WriteVTK, LinearAlgebra
# 😀  Get edge smoothed domain
function GetCellEdgSD!(SD, element, node, nele)
    #=
    SD为保存的光滑域信息，5维矩阵，【4,4,k,m,n】  n为单元数量，m为每个单元的
    光滑域part部分，k为每个part所包含的面.
    =#
    ib = blockIdx().x
    it = (ib - 1) * blockDim().x + threadIdx().x
    if it > nele
        return nothing
    end
    stride = (gridDim().x) * blockDim().x

    for id in range(it, step = stride, nele)

        for i = 1:6
            N1 = element[id, 1]
            N2 = element[id, 2]
            N3 = element[id, 3]
            N4 = element[id, 4]
            v = 0
            if i == 1
                edg1 = N1
                edg2 = N2
                # a=setdiff(cell,edg)
                a1 = N3
                a2 = N4
            elseif i == 2
                edg1 = N1
                edg2 = N3
                a1 = N2
                a2 = N4
            elseif i == 3
                edg1 = N1
                edg2 = N4
                a1 = N2
                a2 = N3
            elseif i == 4
                edg1 = N2
                edg2 = N3
                a1 = N1
                a2 = N4
            elseif i == 5
                edg1 = N2
                edg2 = N4
                a1 = N1
                a2 = N3
            elseif i == 6
                edg1 = N3
                edg2 = N4
                a1 = N1
                a2 = N2
            end
            # face1=[edg;a[1]]
            # face2=[edg;a[2]]
            face11, face12, face13 = edg1, edg2, a1
            face21, face22, face23 = edg1, edg2, a2
            # fcenter1=(sum(node[face1,:],dims=1)/3)#面中心
            fcenter1x = (node[edg1, 1] + node[edg2, 1] + node[a1, 1]) / 3
            fcenter1y = (node[edg1, 2] + node[edg2, 2] + node[a1, 2]) / 3
            fcenter1z = (node[edg1, 3] + node[edg2, 3] + node[a1, 3]) / 3
            # fcenter2=(sum(node[face2,:],dims=1)/3)#面中心
            fcenter2x = (node[edg1, 1] + node[edg2, 1] + node[a2, 1]) / 3
            fcenter2y = (node[edg1, 2] + node[edg2, 2] + node[a2, 2]) / 3
            fcenter2z = (node[edg1, 3] + node[edg2, 3] + node[a2, 3]) / 3
            # center=(fcenter1+fcenter2)/2#多面体内部点
            centerx = (fcenter1x + fcenter2x) / 2
            centery = (fcenter1y + fcenter2y) / 2
            centerz = (fcenter1z + fcenter2z) / 2
            # cc=sum(node[cell,:],dims=1)/4#体中心
            ccx = (node[N1, 1] + node[N2, 1] + node[N3, 1] + node[N4, 1]) / 4
            ccy = (node[N1, 2] + node[N2, 2] + node[N3, 2] + node[N4, 2]) / 4
            ccz = (node[N1, 3] + node[N2, 3] + node[N3, 3] + node[N4, 3]) / 4
            #面1
            # tri=[node[edg,:];fcenter1]
            # area=AreaTri(tri)
            v1x = node[edg2, 1] - node[edg1, 1]
            v1y = node[edg2, 2] - node[edg1, 2]
            v1z = node[edg2, 3] - node[edg1, 3]

            v2x = fcenter1x - node[edg1, 1]
            v2y = fcenter1y - node[edg1, 2]
            v2z = fcenter1z - node[edg1, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5

            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg1, 1] - centerx
            jy = node[edg1, 2] - centery
            jz = node[edg1, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[edg1, 1], node[edg1, 2], node[edg1, 3])) / 3
            # SD[:,:,1,i]=[edg1 edg2  a1     fn1
            #              0      0   edg1   fn2
            #              0      0   edg2   fn3
            #              0      0     0    area]
            SD[1, 1, 1, i, id] = edg1
            SD[1, 2, 1, i, id] = edg2
            SD[1, 3, 1, i, id] = a1
            SD[1, 4, 1, i, id] = f1
            SD[2, 3, 1, i, id] = edg1
            SD[2, 4, 1, i, id] = f2
            SD[3, 3, 1, i, id] = edg2
            SD[3, 4, 1, i, id] = f3
            SD[4, 4, 1, i, id] = area
            # SD[4,1,1,i,id]=v 
            #面2
            v1x = node[edg2, 1] - node[edg1, 1]
            v1y = node[edg2, 2] - node[edg1, 2]
            v1z = node[edg2, 3] - node[edg1, 3]

            v2x = fcenter2x - node[edg1, 1]
            v2y = fcenter2y - node[edg1, 2]
            v2z = fcenter2z - node[edg1, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5
            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg1, 1] - centerx
            jy = node[edg1, 2] - centery
            jz = node[edg1, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[edg1, 1], node[edg1, 2], node[edg1, 3])) / 3
            SD[1, 1, 2, i, id] = edg1
            SD[1, 2, 2, i, id] = edg2
            SD[1, 3, 2, i, id] = a2
            SD[1, 4, 2, i, id] = f1

            SD[2, 3, 2, i, id] = edg1
            SD[2, 4, 2, i, id] = f2

            SD[3, 3, 2, i, id] = edg2
            SD[3, 4, 2, i, id] = f3
            SD[4, 4, 2, i, id] = area
            # SD[4,1,2,i,id]=v 
            #面3
            v1x = fcenter1x - node[edg1, 1]
            v1y = fcenter1y - node[edg1, 2]
            v1z = fcenter1z - node[edg1, 3]

            v2x = ccx - node[edg1, 1]
            v2y = ccy - node[edg1, 2]
            v2z = ccz - node[edg1, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5
            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg1, 1] - centerx
            jy = node[edg1, 2] - centery
            jz = node[edg1, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[edg1, 1], node[edg1, 2], node[edg1, 3])) / 3
            SD[1, 1, 3, i, id] = edg1
            SD[1, 2, 3, i, id] = face11
            SD[1, 3, 3, i, id] = N1
            SD[1, 4, 3, i, id] = f1

            SD[2, 2, 3, i, id] = face12
            SD[2, 3, 3, i, id] = N2
            SD[2, 4, 3, i, id] = f2

            SD[3, 2, 3, i, id] = face13
            SD[3, 3, 3, i, id] = N3
            SD[3, 4, 3, i, id] = f3

            SD[4, 3, 3, i, id] = N4
            SD[4, 4, 3, i, id] = area
            # SD[4,1,3,i,id]=v 
            #面4
            v1x = fcenter1x - node[edg2, 1]
            v1y = fcenter1y - node[edg2, 2]
            v1z = fcenter1z - node[edg2, 3]

            v2x = ccx - node[edg2, 1]
            v2y = ccy - node[edg2, 2]
            v2z = ccz - node[edg2, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5
            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg2, 1] - centerx
            jy = node[edg2, 2] - centery
            jz = node[edg2, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end

            v = v + area * (mydot(f1, f2, f3, node[edg2, 1], node[edg2, 2], node[edg2, 3])) / 3
            SD[1, 1, 4, i, id] = edg2
            SD[1, 2, 4, i, id] = face11
            SD[1, 3, 4, i, id] = N1
            SD[1, 4, 4, i, id] = f1

            SD[2, 2, 4, i, id] = face12
            SD[2, 3, 4, i, id] = N2
            SD[2, 4, 4, i, id] = f2

            SD[3, 2, 4, i, id] = face13
            SD[3, 3, 4, i, id] = N3
            SD[3, 4, 4, i, id] = f3

            SD[4, 3, 4, i, id] = N4
            SD[4, 4, 4, i, id] = area
            # SD[4,1,4,i,id]=v 
            #面5
            v1x = fcenter2x - node[edg1, 1]
            v1y = fcenter2y - node[edg1, 2]
            v1z = fcenter2z - node[edg1, 3]

            v2x = ccx - node[edg1, 1]
            v2y = ccy - node[edg1, 2]
            v2z = ccz - node[edg1, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5
            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg1, 1] - centerx
            jy = node[edg1, 2] - centery
            jz = node[edg1, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end

            v = v + area * (mydot(f1, f2, f3, node[edg1, 1], node[edg1, 2], node[edg1, 3])) / 3
            SD[1, 1, 5, i, id] = edg1
            SD[1, 2, 5, i, id] = face21
            SD[1, 3, 5, i, id] = N1
            SD[1, 4, 5, i, id] = f1

            SD[2, 2, 5, i, id] = face22
            SD[2, 3, 5, i, id] = N2
            SD[2, 4, 5, i, id] = f2

            SD[3, 2, 5, i, id] = face23
            SD[3, 3, 5, i, id] = N3
            SD[3, 4, 5, i, id] = f3

            SD[4, 3, 5, i, id] = N4
            SD[4, 4, 5, i, id] = area
            # SD[4,1,5,i,id]=v 
            #面6
            v1x = fcenter2x - node[edg2, 1]
            v1y = fcenter2y - node[edg2, 2]
            v1z = fcenter2z - node[edg2, 3]

            v2x = ccx - node[edg2, 1]
            v2y = ccy - node[edg2, 2]
            v2z = ccz - node[edg2, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5
            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg2, 1] - centerx
            jy = node[edg2, 2] - centery
            jz = node[edg2, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end

            v = v + area * (mydot(f1, f2, f3, node[edg2, 1], node[edg2, 2], node[edg2, 3])) / 3
            SD[1, 1, 6, i, id] = edg2
            SD[1, 2, 6, i, id] = face21
            SD[1, 3, 6, i, id] = N1
            SD[1, 4, 6, i, id] = f1

            SD[2, 2, 6, i, id] = face22
            SD[2, 3, 6, i, id] = N2
            SD[2, 4, 6, i, id] = f2

            SD[3, 2, 6, i, id] = face23
            SD[3, 3, 6, i, id] = N3
            SD[3, 4, 6, i, id] = f3

            SD[4, 3, 6, i, id] = N4
            SD[4, 4, 6, i, id] = area
            SD[4, 1, 6, i, id] = v
        end

    end
    return nothing
end

function mycross(a, b, c, e, f, g)#计算叉乘
    return b * g - c * f, e * c - a * g, a * f - e * b
end

function mydot(a, b, c, e, f, g)
    return a * e + b * f + c * g
end

function mynorm(a, b, c)
    return (a^2 + b^2 + c^2)^0.5
end

function mynormalize(a, b, c)
    l = (a^2 + b^2 + c^2)^0.5
    return a / l, b / l, c / l
end

function GetTriArea(p)
    v1=p[2,:]-p[1,:]
    v2=p[3,:]-p[1,:]
    s=norm(cross(v1,v2))/2
    return s
end

#😀 Cell-based smoothed domain
function GetCellNodeSD!(SD, element, node, nele)
    #=
    SD为保存的光滑域信息，5维矩阵，【4,4,k,m,n】  n为单元数量，m为每个单元的
    光滑域part部分，k为每个part所包含的面.
    =#
    ib = blockIdx().x
    it = (ib - 1) * blockDim().x + threadIdx().x
    if it > nele
        return nothing
    end
    stride = (gridDim().x) * blockDim().x

    for id in range(it, step = stride, nele)
        N1 = element[id, 1]
        N2 = element[id, 2]
        N3 = element[id, 3]
        N4 = element[id, 4]
        ccx = (node[N1, 1] + node[N2, 1] + node[N3, 1] + node[N4, 1]) / 4
        ccy = (node[N1, 2] + node[N2, 2] + node[N3, 2] + node[N4, 2]) / 4
        ccz = (node[N1, 3] + node[N2, 3] + node[N3, 3] + node[N4, 3]) / 4
        for i = 1:4
            v = 0
            if i == 1
                thenode = N1
                otherp1 = N2
                otherp2 = N3
                otherp3 = N4
            elseif i == 2
                thenode = N2
                otherp1 = N1
                otherp2 = N3
                otherp3 = N4
            elseif i == 3
                thenode = N3
                otherp1 = N1
                otherp2 = N2
                otherp3 = N4
            elseif i == 4
                thenode = N4
                otherp1 = N1
                otherp2 = N2
                otherp3 = N3
            end
            scx = (node[otherp1, 1] + node[otherp2, 1] + node[otherp3, 1] + ccx) / 4
            scy = (node[otherp1, 2] + node[otherp2, 2] + node[otherp3, 2] + ccy) / 4
            scz = (node[otherp1, 3] + node[otherp2, 3] + node[otherp3, 3] + ccz) / 4
            #面1
            jx = node[otherp1, 1] - scx
            jy = node[otherp1, 2] - scy
            jz = node[otherp1, 3] - scz

            v1x = node[otherp1, 1] - ccx
            v1y = node[otherp1, 2] - ccy
            v1z = node[otherp1, 3] - ccz

            v2x = node[otherp2, 1] - ccx
            v2y = node[otherp2, 2] - ccy
            v2z = node[otherp2, 3] - ccz

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5

            f1, f2, f3 = mynormalize(f1, f2, f3)

            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[otherp1, 1], node[otherp1, 2], node[otherp1, 3])) / 3

            SD[1, 1, 1, i, id] = otherp1

            SD[1, 2, 1, i, id] = otherp2

            SD[1, 3, 1, i, id] = N1
            SD[2, 3, 1, i, id] = N2
            SD[3, 3, 1, i, id] = N3
            SD[4, 3, 1, i, id] = N4

            SD[1, 4, 1, i, id] = f1
            SD[2, 4, 1, i, id] = f2
            SD[3, 4, 1, i, id] = f3
            SD[4, 4, 1, i, id] = area
            #面2

            jx = node[otherp2, 1] - scx
            jy = node[otherp2, 2] - scy
            jz = node[otherp2, 3] - scz

            v1x = node[otherp2, 1] - ccx
            v1y = node[otherp2, 2] - ccy
            v1z = node[otherp2, 3] - ccz

            v2x = node[otherp3, 1] - ccx
            v2y = node[otherp3, 2] - ccy
            v2z = node[otherp3, 3] - ccz

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5

            f1, f2, f3 = mynormalize(f1, f2, f3)

            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[otherp2, 1], node[otherp2, 2], node[otherp2, 3])) / 3

            SD[1, 1, 2, i, id] = otherp2

            SD[1, 2, 2, i, id] = otherp3

            SD[1, 3, 2, i, id] = N1
            SD[2, 3, 2, i, id] = N2
            SD[3, 3, 2, i, id] = N3
            SD[4, 3, 2, i, id] = N4

            SD[1, 4, 2, i, id] = f1
            SD[2, 4, 2, i, id] = f2
            SD[3, 4, 2, i, id] = f3
            SD[4, 4, 2, i, id] = area

            #面3

            jx = node[otherp3, 1] - scx
            jy = node[otherp3, 2] - scy
            jz = node[otherp3, 3] - scz

            v1x = node[otherp1, 1] - ccx
            v1y = node[otherp1, 2] - ccy
            v1z = node[otherp1, 3] - ccz

            v2x = node[otherp3, 1] - ccx
            v2y = node[otherp3, 2] - ccy
            v2z = node[otherp3, 3] - ccz

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5

            f1, f2, f3 = mynormalize(f1, f2, f3)

            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[otherp1, 1], node[otherp1, 2], node[otherp1, 3])) / 3

            SD[1, 1, 3, i, id] = otherp3

            SD[1, 2, 3, i, id] = otherp1

            SD[1, 3, 3, i, id] = N1
            SD[2, 3, 3, i, id] = N2
            SD[3, 3, 3, i, id] = N3
            SD[4, 3, 3, i, id] = N4

            SD[1, 4, 3, i, id] = f1
            SD[2, 4, 3, i, id] = f2
            SD[3, 4, 3, i, id] = f3
            SD[4, 4, 3, i, id] = area

            #面4
            jx = node[otherp1, 1] - scx
            jy = node[otherp1, 2] - scy
            jz = node[otherp1, 3] - scz

            v1x = node[otherp2, 1] - node[otherp1, 1]
            v1y = node[otherp2, 2] - node[otherp1, 2]
            v1z = node[otherp2, 3] - node[otherp1, 3]

            v2x = node[otherp3, 1] - node[otherp1, 1]
            v2y = node[otherp3, 2] - node[otherp1, 2]
            v2z = node[otherp3, 3] - node[otherp1, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5

            f1, f2, f3 = mynormalize(f1, f2, f3)

            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[otherp1, 1], node[otherp1, 2], node[otherp1, 3])) / 3

            SD[1, 1, 4, i, id] = otherp1
            SD[4, 1, 4, i, id] = v

            SD[1, 2, 4, i, id] = otherp2

            SD[1, 3, 4, i, id] = otherp3

            SD[1, 4, 4, i, id] = f1
            SD[2, 4, 4, i, id] = f2
            SD[3, 4, 4, i, id] = f3
            SD[4, 4, 4, i, id] = area

        end

    end
    return nothing
end

function GetSDofNode(node, element)
    # element=sort(element,dims=2)
    N = size(element, 1)
    numblocks = ceil(Int, N / 256)
    SD_GPU = CuArray(zeros(4, 4, 4, 4, size(element, 1)))
    element_GPU = CuArray(element)
    node_GPU = CuArray(node)
    # @cuda threads=256 blocks=numblocks 
    @cuda threads = 256 blocks = numblocks GetCellNodeSD!(SD_GPU, element_GPU, node_GPU, N)
    synchronize()
    return Array(SD_GPU)
end

function GetVolume(SD)
    v=zeros(size(SD,5))
    for i=1:size(SD,5)
        for j=1:4
        v[i]+=SD[4,1,4,j,i]
        end
    end
    return v
end


#😊 Cell-based SD stiffness calculation
function GetCellSDMatrix(SD, ele, MAT, MATID)
    #仅计算一个part，不能计算多体
    println("体光滑域计算中...")

    nele = size(SD, 5) * 4
    numofmatrix = 16

    IKV, JKV, VKV = SharedVector{Int32}(numofmatrix * nele), SharedVector{Int32}(numofmatrix * nele), SharedVector{Float64}(numofmatrix * nele)

    IKT, JKT, VKT = SharedVector{Int32}(numofmatrix * nele), SharedVector{Int32}(numofmatrix * nele), SharedVector{Float64}(numofmatrix * nele)

    HD = SharedArray(zeros(Float64, 3, 4, 4, size(SD, 5)))

    SD = SharedArray(SD)

    ele = SharedArray(ele)

    GetCellSDMatrix2!(HD, SD, MAT, MATID, IKV, JKV, VKV, IKT, JKT, VKT, ele)

    # return IKV,JKV,VKV,IKT,JKT,VKT
    return sparse(IKV, JKV, VKV), sparse(IKT, JKT, VKT), HD

end

function GetCellSDMatrix2!(HD, SD, MAT, MATID, IKV, JKV, VKV, IKT, JKT, VKT, ele)
    # 
    @inbounds @sync @distributed for i = 1:size(SD, 5)
        for j = 1:4
            for k = 1:4
                for c = 1:3

                    m = 0
                    for r = 1:4
                        if SD[r, c, k, j, i] != 0
                            m = m + 1
                        end
                    end

                    if k == 4
                        if c == 1
                            m = m - 1
                        end
                    end

                    for r = 1:m
                        nodeid = findfirst(x -> x == SD[r, c, k, j, i], ele[i, :])
                        # @show SD[r,c,k,j,i]
                        # @show ele[i,:]
                        HD[:, nodeid, j, i] += ((1 / 3) / m) * SD[4, 4, k, j, i] * SD[1:3, 4, k, j, i]
                    end
                end
            end

            HH = HD[:, :, j, i]

            C = MAT[MATID[i], :]

            λ = C[1] #热导率

            ϵ = C[2] #电导率

            KV = (HH' * ϵ * HH) / SD[4, 1, 4, j, i]

            KT = (HH' * λ * HH) / SD[4, 1, 4, j, i]

            dof = ele[i, :]

            start = (4 * (i - 1) + j - 1) * 16

            AssembleIJK!(KV, dof, IKV, JKV, VKV, start)

            AssembleIJK!(KT, dof, IKT, JKT, VKT, start)
        end

    end
end

function AssembleIJK!(ke,dof,IK,JK,VK,start)
    for i=1:size(ke,1)
        for j=1:size(ke,1)
            start+=1
            IK[start]=dof[i]
            JK[start]=dof[j]
            VK[start]=ke[i,j]
            
        end
    end
    return nothing
end

#😊 施加固定电压
function AddEssBdy_Vol(K, F, BDY, value) # 施加本质边界条件，电压
    DOF = unique(BDY[:])
    for i = 1:size(DOF, 1)
        a = Int64(DOF[i, 1])
        K[a, :] .= 0
        K[a, a] = 1
        F[a] = value
    end
    return K, F
end

#😊 荷载计算电流边界
function CurFlowBoundary(node,BDY,value)
    node=SharedArray(node)
    BDY=SharedArray(BDY)
    F=SharedVector(zeros(size(node,1)))
    value=SharedArray([value])
    @inbounds @sync @distributed for i=1:size(BDY,1)
        dof=BDY[i,1:3]
        s=GetTriArea(node[dof,:])
        sp=value[1]*s/3
        for j=1:3
            F[dof[j]]+=sp

        end
    end
    return F
end

function AssembleIJK(IK,JK,VK,ke,DOF)
    for i=1:size(ke,1)
        for j=1:size(ke,1)
            IK = append!(IK,DOF[i])
            JK = append!(JK,DOF[j])
            VK = append!(VK,ke[i,j])
        end
    end
    return IK,JK,VK
end

#😊 对流换热
function HcBoundary(node, BDY, h, ue)
    F=CurFlowBoundary(node, BDY, h*ue)
    nbdy=size(BDY,1)
    # IK, JK, VK = SharedVector(Vector{Int32}(nbdy*3)), Vector{Int32}(nbdy*3), Vector{Float64}(nbdy*3)
    IK, JK, VK = SharedVector{Int32}(nbdy*3), SharedVector{Int32}(nbdy*3), SharedVector{Float64}(nbdy*3)
    for i=1:size(BDY,1)
        dof=BDY[i,1:3]
        s=GetTriArea(node[dof,:])
        sp=h*s/3
        for j=1:3
            # push!(IK,dof[j])
            # push!(JK,dof[j])
            # push!(VK,sp)
            start=3*(i-1)
            IK[start+j]=dof[j]
            JK[start+j]=dof[j]
            VK[start+j]=sp
        end
    end
    return IK,JK,VK,F
end

function AddIJVK(K, IK, JK, VK)
    for i = 1:length(IK)
        K[IK[i], JK[i]] += VK[i]
    end
    return K
end

function GetQualityMatrix(node,element,SD,MAT,MATID)
    F=zeros(size(node,1))
    for i=1:size(element,1)
       dof=element[i,:]
       the_mat=MAT[MATID[i],:]
       the_v=0
       for j=1:4
           the_v+=SD[4,1,4,j,i]
       end
       
       value=the_mat[3]*the_mat[4]*the_v/4
       for j=1:length(dof)
           F[dof[j]]+=value
       end

    end
    return F
end

function GetGradient(node,element,re)
    nn=size(node,1)
    Elegra=Vector{Any}(nothing,nn)
    for i=1:size(element,1)
        dof=element[i,:]
        the_re=re[dof]
        the_col=node[dof,:]
        
        the_col[2,:]=the_col[2,:]-the_col[1,:]
        the_col[3,:]=the_col[3,:]-the_col[1,:]
        the_col[4,:]=the_col[4,:]-the_col[1,:]
        the_col[1,:].=0
        #[1,x,y,z]
        A=ones(4,4)
        A[:,2:4]=the_col
    end

end


#😊 计算焦耳热
function GetJoulSource(node, element, HD, SD, u, MAT, MATID)
    QJ = SharedVector(zeros(size(node, 1)))
    node=SharedArray(node)
    element=SharedArray(element)
    # HD=SharedArray(HD)
    SD=SharedArray(SD)
    u=SharedArray(u)
    MAT=SharedArray(MAT)
    MATID=SharedArray(MATID)

    @inbounds @sync @distributed for i = 1:size(element, 1)
        uele = u[element[i, :]]
        h = zeros(4)
        C = MAT[MATID[i], :]
        for j = 1:4
            dof = setdiff(1:4, j)
            v = SD[4, 1, 4, j, i]
            B = HD[:, :, j, i] / v
            E = B * uele

            qj = dot(E, C[2] * E)

            ih = v / 4

            h[dof[1]] += ih[1] * 1.25 * qj
            h[dof[2]] += ih[1] * 1.25 * qj
            h[dof[3]] += ih[1] * 1.25 * qj
            h[j] += ih[1] * 0.25 * qj
        end

        a = element[i, :]
        for k = 1:4
            QJ[a[k]] += h[k]
        end
    end

    return QJ
end

#😊 solve
function Solve(KE, Q, num)
    ps = MKLPardisoSolver()
    set_nprocs!(ps, num)
    result = similar(Q)
    result = solve(ps, KE, Q)
end

#😊 write result
function writeResulttovtk_TET(node, element; r = [], name = "undefine", des = "undefine")
    cells = MeshCell[]
    for i = 1:size(element, 1)
        a = MeshCell(VTKCellType(10), element[i, :])
        push!(cells, a)
    end
    vtkfile = vtk_grid(name, node[:, 1], node[:, 2], node[:, 3], cells)
    if !isempty(r)
        vtkfile[des, VTKPointData()] = r
    end
    outfiles = vtk_save(vtkfile)
end

end

##