module DT_bushing
    using SparseArrays,DelimitedFiles,LinearAlgebra
    #****************************************************************电场计算*****************************************************************
    #刚度矩阵计算
    function Getelemat(node, element, Mlist)
        nele = size(element, 1)
        IK = Vector{Int64}(); JK = Vector{Int64}(); VK = Vector{Float64}()
        IK2 = Vector{Int64}(); JK2 = Vector{Int64}(); VK2 = Vector{Float64}()
        for i = 1:nele
            a = element[i,1:(end-1)]
            single_ele = node[a,:]
            the_mat=Mlist[element[i,end],:]
            the_K,the_K2= Getelemat2(single_ele, the_mat)
            IK,JK,VK=AssembleIJK(IK,JK,VK,the_K,a)
            IK2,JK2,VK2=AssembleIJK(IK2,JK2,VK2,the_K2,a)
        end
        K=sparse(IK,JK,VK)
        K2=sparse(IK2,JK2,VK2)
        return K , K2
    end 

    function AssembleIJK(IK,JK,VK,ke,DOF)
        for i=1:size(ke,1)
            for j=1:size(ke,1)
                IK = append!(IK,DOF[i])
                JK = append!(JK,DOF[j])
                VK = append!(VK,ke[i,j])
            end
        end
        return IK,JK,VK
    end

    function Getelemat2(ele, mlist)
        gpx = gpy = gpz = [0.577350269189626,-0.577350269189626]
        K = zeros(8,8)
        K2 = zeros(8,8)
        for i = 1:2
            for j = 1:2
                for k = 1:2
                    A,B= Getelemat3(gpx[i], gpy[j], gpz[k], mlist, ele)
                    K+=A
                    K2+=B
                end
            end
        end
        return K,K2
    end

    function Getelemat3(r, s, t, MAT, ele)
        # 形函数 h(r,s,t)=0.125*[(1-r)*(1-s)*(1-t) (1+r)*(1-s)*(1-t) (1+r)*(1+s)*(1-t) (1-r)*(1+s)*(1-t) (1-r)*(1-s)*(1+t) (1+r)*(1-s)*(1+t) (1+r)*(1+s)*(1+t) (1-r)*(1+s)*(1+t)];
        hdr = [-((s - 1) * (t - 1)) / 8, ((s - 1) * (t - 1)) / 8, -((s + 1) * (t - 1)) / 8, ((s + 1) * (t - 1)) / 8, ((s - 1) * (t + 1)) / 8,-((s - 1) * (t + 1)) / 8, ((s + 1) * (t + 1)) / 8, -((s + 1) * (t + 1)) / 8]
        hds = [-((r - 1) * (t - 1)) / 8, ((r + 1) * (t - 1)) / 8, -((r + 1) * (t - 1)) / 8, ((r - 1) * (t - 1)) / 8, ((r - 1) * (t + 1)) / 8, -((r + 1) * (t + 1)) / 8, ((r + 1) * (t + 1)) / 8, -((r - 1) * (t + 1)) / 8]
        hdt = [-((r - 1) * (s - 1)) / 8, ((r + 1) * (s - 1)) / 8, -((r + 1) * (s + 1)) / 8, ((r - 1) * (s + 1)) / 8, ((r - 1) * (s - 1)) / 8, -((r + 1) * (s - 1)) / 8, ((r + 1) * (s + 1)) / 8, -((r - 1) * (s + 1)) / 8]
        h=0.125*[(1-r)*(1-s)*(1-t),(1+r)*(1-s)*(1-t),(1+r)*(1+s)*(1-t),(1-r)*(1+s)*(1-t),(1-r)*(1-s)*(1+t),(1+r)*(1-s)*(1+t),(1+r)*(1+s)*(1+t),(1-r)*(1+s)*(1+t)];
        ##雅可比矩阵
        J = zeros(3, 3)
        J[1,1] = (ele[:,1]') * hdr
        J[1,2] = (ele[:,2]') * hdr
        J[1,3] = (ele[:,3]') * hdr

        J[2,1] = (ele[:,1]') * hds
        J[2,2] = (ele[:,2]') * hds
        J[2,3] = (ele[:,3]') * hds

        J[3,1] = (ele[:,1]') * hdt
        J[3,2] = (ele[:,2]') * hdt
        J[3,3] = (ele[:,3]') * hdt
        DJ = abs(det(J))
        
        # 导数变化
        hd = [hdr hds hdt]
        hd = J \ hd'


        # 材料矩阵
        λ=MAT[2];#电导率
        C1=[λ 0 0;0 λ 0;0 0 λ];

        C2=[MAT[1] 0 0;0 MAT[1] 0;0 0 MAT[1]];
        #增量矩阵K
        KT=(hd')*C1*hd*DJ
        K2=(hd')*C2*hd*DJ
        # 被积函数
        return KT,K2
    end

    #荷载计算电流边界
    function CurFlowBoundary(node,bdy,qb)
        n=size(node,1)
        F=zeros(n)
        for i=1:size(bdy,1)
            a=bdy[i,:]
            DOF=a
            col=node[a,:]
            the_fh=CurFlowBoundary1(col,qb)
            F[DOF]+=the_fh
        end
        return F
    end

    function CurFlowBoundary1(p,qb)
        #坐标到2D
        p[2,:] = p[2,:] - p[1,:]
        p[3,:] = p[3,:] - p[1,:]
        p[4,:] = p[4,:] - p[1,:]
        fx = normalize(p[2,:])
        fy=normalize(cross(cross(fx,p[3,:]),fx))
        pp = zeros(4, 2)
        for i = 2:4
            pp[i,:] = [dot(p[i,:], fx),dot(p[i,:],fy)]
        end
        #开始
        r = s = [0.577350269189626,-0.577350269189626]
        F = zeros(4)
        for i in r 
            for j in s
                B=CurFlowBoundary2(pp,qb,i,j)
                F+=B
            end
        end
        return F
    end

    function CurFlowBoundary2(col,qb,r,s)
        H=[0.25 * (1 - r) * (1 - s),0.25 * (1 + r) * (1 - s),0.25 * (1 + r) * (1 + s),0.25 * (1 - r) * (1 + s)]
        Hd = [s - 1 1-s s + 1 -1 - s
        r - 1 -1 - r  r + 1  1-r] * 0.25
        J = zeros(2, 2)
        x=col[:,1]
        y=col[:,2]
        J[1, 1] = x' * Hd[1, :]
        J[1, 2] = y' * Hd[1, :]
        J[2, 1] = x' * Hd[2, :]
        J[2, 2] = y' * Hd[2, :]
        DJ=abs(det(J))
        #计算当前换热系数
        F=H*qb*DJ
        return F
    end

    #本质边界
    function AddEssBdy(K, F,DOF) # 施加本质边界条件，bdy 第一列为自由度序号，第二列为自由度限制值
        for i = 1:size(DOF, 1)
            a = Int64(DOF[i,1])
            K[a,:] .= 0
            K[a,a] = 1
            F[a] = DOF[i,2]
        end
        return K, F
    end

    #****************************************************************温度场计算*****************************************************************
    #刚度矩阵和热容矩阵
    function TGetelemat(node, element, Mlist,V)
        nele = size(element, 1)

        F=zeros(size(node,1))

        for i = 1:nele
            a = element[i,1:(end-1)]
            single_ele = node[a,:]
            the_mat=Mlist[element[i,end],:]
            the_V=V[a]
            the_F= TGetelemat2(single_ele, the_mat,the_V)

            for j=1:length(a)
                F[a[j]]+=the_F[j]
            end
        end

        return F
    end 

    function TGetelemat2(ele, mlist,V)
        gpx = gpy = gpz = [0.577350269189626,-0.577350269189626]
        F = zeros(8)
        for i = 1:2
            for j = 1:2
                for k = 1:2
                    A= TGetelemat3(gpx[i], gpy[j], gpz[k], mlist, ele,V)
                    F+=A
                end
            end
        end
        return F
    end
    
    function TGetelemat3(r, s, t, MAT, ele,V)
        hdr = [-((s - 1) * (t - 1)) / 8, ((s - 1) * (t - 1)) / 8, -((s + 1) * (t - 1)) / 8, ((s + 1) * (t - 1)) / 8, ((s - 1) * (t + 1)) / 8,-((s - 1) * (t + 1)) / 8, ((s + 1) * (t + 1)) / 8, -((s + 1) * (t + 1)) / 8]
        hds = [-((r - 1) * (t - 1)) / 8, ((r + 1) * (t - 1)) / 8, -((r + 1) * (t - 1)) / 8, ((r - 1) * (t - 1)) / 8, ((r - 1) * (t + 1)) / 8, -((r + 1) * (t + 1)) / 8, ((r + 1) * (t + 1)) / 8, -((r - 1) * (t + 1)) / 8]
        hdt = [-((r - 1) * (s - 1)) / 8, ((r + 1) * (s - 1)) / 8, -((r + 1) * (s + 1)) / 8, ((r - 1) * (s + 1)) / 8, ((r - 1) * (s - 1)) / 8, -((r + 1) * (s - 1)) / 8, ((r + 1) * (s + 1)) / 8, -((r - 1) * (s + 1)) / 8]
        h=0.125*[(1-r)*(1-s)*(1-t),(1+r)*(1-s)*(1-t),(1+r)*(1+s)*(1-t),(1-r)*(1+s)*(1-t),(1-r)*(1-s)*(1+t),(1+r)*(1-s)*(1+t),(1+r)*(1+s)*(1+t),(1-r)*(1+s)*(1+t)];
        ##雅可比矩阵
        J = zeros(3, 3)
        J[1,1] = (ele[:,1]') * hdr
        J[1,2] = (ele[:,2]') * hdr
        J[1,3] = (ele[:,3]') * hdr
    
        J[2,1] = (ele[:,1]') * hds
        J[2,2] = (ele[:,2]') * hds
        J[2,3] = (ele[:,3]') * hds
    
        J[3,1] = (ele[:,1]') * hdt
        J[3,2] = (ele[:,2]') * hdt
        J[3,3] = (ele[:,3]') * hdt
        DJ = abs(det(J))
        
        # 导数变化
        hd = [hdr hds hdt]
        hd = J \ hd'
    
        # 材料矩阵
        # λ=MAT[1];
        ϵ=MAT[2];#导热系数与电导率
        # C1=[λ 0 0;0 λ 0;0 0 λ];
        C2=[ϵ 0 0;0 ϵ 0;0 0 ϵ];
        #增量矩阵K
        # KT=(hd')*C1*hd*DJ

        # ρ=MAT[3]
        # c=MAT[4]

        # KP=ρ*c*(h)*(h')*DJ

        #对于绝缘体不算热
        # if ϵ<10
        #     FJ=zeros(8)
        # else
        E=hd*V
        FJ=h*(dot((C2*E),E))*DJ
        # end
    
        # 被积函数
        return FJ
    
    end

    ##对流换热
    function HcBoundary(node,bdy,h,ue)
        n=size(node,1)
        IK = Vector{Int64}(); JK = Vector{Int64}(); VK = Vector{Float64}()
        F=zeros(n)
        for i=1:size(bdy,1)
            a=bdy[i,:]
            col=node[a,:]
            the_kh,the_fh=GetStiffnessHc1(col,h,ue)
            IK,JK,VK=AssembleIJK(IK,JK,VK,the_kh,a)
            for j=1:length(a)
                F[a[j]]+=the_fh[j]
            end
        end
        return IK,JK,VK,F
    end
    
    function GetStiffnessHc1(p,fh,ue)
        #坐标到2D
        p[2,:] = p[2,:] - p[1,:]
        p[3,:] = p[3,:] - p[1,:]
        p[4,:] = p[4,:] - p[1,:]
        fx = normalize(p[2,:])
        fy=normalize(cross(cross(fx,p[3,:]),fx))
        pp = zeros(4, 2)
        for i = 2:4
            pp[i,:] = [dot(p[i,:], fx),dot(p[i,:],fy)]
        end
        #开始
        r = s = [0.577350269189626,-0.577350269189626]
        K = zeros(4,4)
        F = zeros(4)
        for i in r 
            for j in s
                A,B=GetStiffnessHc2(pp,fh,ue,i,j)
                K+=A
                F+=B
            end
        end
        return K,F
    end
    
    function GetStiffnessHc2(col,fh,ue,r,s)
        H=[0.25 * (1 - r) * (1 - s),0.25 * (1 + r) * (1 - s),0.25 * (1 + r) * (1 + s),0.25 * (1 - r) * (1 + s)]
        Hd = [s - 1 1-s s + 1 -1 - s
        r - 1 -1 - r  r + 1  1-r] * 0.25
        J = zeros(2, 2)
        x=col[:,1]
        y=col[:,2]
        J[1, 1] = x' * Hd[1, :]
        J[1, 2] = y' * Hd[1, :]
        J[2, 1] = x' * Hd[2, :]
        J[2, 2] = y' * Hd[2, :]
        DJ=abs(det(J))
    
        K=H*fh*(H')*DJ
    
        F=H*fh*(ue)*DJ
    
        return K,F
    
    end
    
    function AddIJVK(K,IK,JK,VK)
        for i=1:length(IK)
            K[IK[i],JK[i]]+=VK[i]
        end
        return K
    end

    #****************************************************************耦合计算*****************************************************************
    function Couple_TV(pos,qb,tl,nt,T0,h,ue)
         # 文件读取
        node=readdlm(string(pos,"/node.txt"),Float64)[:,2:4]
        element=readdlm(string(pos,"/element.txt"),Int64)[:,push!(collect(12:19),1)]
        BDY1=readdlm(string(pos,"/BDYZR1.txt"),Int64)[:,6:9]
        BDY2=readdlm(string(pos,"/BDYZR2.txt"),Int64)[:,6:9]
        BDY3=readdlm(string(pos,"/BDYZR3.txt"),Int64)[:,6:9]
        BDY4=readdlm(string(pos,"/BDYZR4.txt"),Int64)[:,6:9]
        BDY5=readdlm(string(pos,"/BDYZR5.txt"),Int64)[:,6:9]
        BDY6=readdlm(string(pos,"/BDYZR6.txt"),Int64)[:,6:9]
         # 材料
        sf6=[60.02 1e-16 21.35 665.18]
        al=[237 35.5e6 2770 880]
        xj=[200 1e-16 3000 500]
        hysz=[2 1e-16 3100 550]
        cu=[400 5.998e7 7900 470]
        MAT=[al;al;al;al;al;hysz;xj;sf6;sf6;al;cu]
         # 边界条件
        qb=qb/(9.3643e-4)

        #求解电场
        DOFU1=unique(BDY4[:])

        BZ1=zeros(size(DOFU1,1),2)

        BZ1[:,1]=DOFU1
        BZ1[:,2] .=110000

        DOFU2=unique(BDY3[:])

        BZ2=zeros(size(DOFU2,1),2)

        BZ2[:,1]=DOFU2

        BZ=[BZ1;BZ2]

        K=Getelemat(node, element, MAT)

        Fcur1=CurFlowBoundary(node,BDY1,qb)

        Fcur2=CurFlowBoundary(node,BDY2,-qb)

        FG=Fcur1+Fcur2

        KG,FG=AddEssBdy(K,FG,BZ)

        V=KG\FG
        println("电场计算完成")
        # 求解温度场
        KT,KP,FJ=TGetelemat(node, element, MAT,V)

        IK,JK,VK,FC=HcBoundary(node,BDY6,h,ue)

        KT=AddIJVK(KT,IK,JK,VK)

        FT=FJ+FC
        #本质边界
        DOFT1=unique(BDY5[:])
        BZ1=zeros(size(DOFT1,1),2)
        BZ1[:,1]=DOFT1
        BZ1[:,2] .=60

        # KT1,FT1=AddEssBdy(KT,FT,BZ1)

        # TT=KT1\FT1



        dt=tl/nt

        t=0
        Tout=[]

        while t<tl

            t+=dt
            KG=(KP+dt*KT)
            FG=(dt*FT+KP*T0)
            KG,FG=AddEssBdy(KG,FG,BZ1)
            T1=KG\FG

            push!(Tout,T1)

            T0=T1

        end

        return V,Tout

    end

    
end