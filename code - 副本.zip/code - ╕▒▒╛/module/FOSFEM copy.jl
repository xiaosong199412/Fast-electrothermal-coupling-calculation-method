module FOSFEM
using CUDA, SparseArrays, SharedArrays, Distributed, Pardiso, WriteVTK, LinearAlgebra
# 😀  Get edge smoothed domain
function GetCellEdgSD!(SD, element, node, nele)
    #=
    SD为保存的光滑域信息，5维矩阵，【4,4,k,m,n】  n为单元数量，m为每个单元的
    光滑域part部分，k为每个part所包含的面.
    =#
    ib = blockIdx().x
    it = (ib - 1) * blockDim().x + threadIdx().x
    if it > nele
        return nothing
    end
    stride = (gridDim().x) * blockDim().x

    for id in range(it, step = stride, nele)

        for i = 1:6
            N1 = element[id, 1]
            N2 = element[id, 2]
            N3 = element[id, 3]
            N4 = element[id, 4]
            v = 0
            if i == 1
                edg1 = N1
                edg2 = N2
                # a=setdiff(cell,edg)
                a1 = N3
                a2 = N4
            elseif i == 2
                edg1 = N1
                edg2 = N3
                a1 = N2
                a2 = N4
            elseif i == 3
                edg1 = N1
                edg2 = N4
                a1 = N2
                a2 = N3
            elseif i == 4
                edg1 = N2
                edg2 = N3
                a1 = N1
                a2 = N4
            elseif i == 5
                edg1 = N2
                edg2 = N4
                a1 = N1
                a2 = N3
            elseif i == 6
                edg1 = N3
                edg2 = N4
                a1 = N1
                a2 = N2
            end
            # face1=[edg;a[1]]
            # face2=[edg;a[2]]
            face11, face12, face13 = edg1, edg2, a1
            face21, face22, face23 = edg1, edg2, a2
            # fcenter1=(sum(node[face1,:],dims=1)/3)#面中心
            fcenter1x = (node[edg1, 1] + node[edg2, 1] + node[a1, 1]) / 3
            fcenter1y = (node[edg1, 2] + node[edg2, 2] + node[a1, 2]) / 3
            fcenter1z = (node[edg1, 3] + node[edg2, 3] + node[a1, 3]) / 3
            # fcenter2=(sum(node[face2,:],dims=1)/3)#面中心
            fcenter2x = (node[edg1, 1] + node[edg2, 1] + node[a2, 1]) / 3
            fcenter2y = (node[edg1, 2] + node[edg2, 2] + node[a2, 2]) / 3
            fcenter2z = (node[edg1, 3] + node[edg2, 3] + node[a2, 3]) / 3
            # center=(fcenter1+fcenter2)/2#多面体内部点
            centerx = (fcenter1x + fcenter2x) / 2
            centery = (fcenter1y + fcenter2y) / 2
            centerz = (fcenter1z + fcenter2z) / 2
            # cc=sum(node[cell,:],dims=1)/4#体中心
            ccx = (node[N1, 1] + node[N2, 1] + node[N3, 1] + node[N4, 1]) / 4
            ccy = (node[N1, 2] + node[N2, 2] + node[N3, 2] + node[N4, 2]) / 4
            ccz = (node[N1, 3] + node[N2, 3] + node[N3, 3] + node[N4, 3]) / 4
            #面1
            # tri=[node[edg,:];fcenter1]
            # area=AreaTri(tri)
            v1x = node[edg2, 1] - node[edg1, 1]
            v1y = node[edg2, 2] - node[edg1, 2]
            v1z = node[edg2, 3] - node[edg1, 3]

            v2x = fcenter1x - node[edg1, 1]
            v2y = fcenter1y - node[edg1, 2]
            v2z = fcenter1z - node[edg1, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5

            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg1, 1] - centerx
            jy = node[edg1, 2] - centery
            jz = node[edg1, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[edg1, 1], node[edg1, 2], node[edg1, 3])) / 3
            # SD[:,:,1,i]=[edg1 edg2  a1     fn1
            #              0      0   edg1   fn2
            #              0      0   edg2   fn3
            #              0      0     0    area]
            SD[1, 1, 1, i, id] = edg1
            SD[1, 2, 1, i, id] = edg2
            SD[1, 3, 1, i, id] = a1
            SD[1, 4, 1, i, id] = f1
            SD[2, 3, 1, i, id] = edg1
            SD[2, 4, 1, i, id] = f2
            SD[3, 3, 1, i, id] = edg2
            SD[3, 4, 1, i, id] = f3
            SD[4, 4, 1, i, id] = area
            # SD[4,1,1,i,id]=v 
            #面2
            v1x = node[edg2, 1] - node[edg1, 1]
            v1y = node[edg2, 2] - node[edg1, 2]
            v1z = node[edg2, 3] - node[edg1, 3]

            v2x = fcenter2x - node[edg1, 1]
            v2y = fcenter2y - node[edg1, 2]
            v2z = fcenter2z - node[edg1, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5
            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg1, 1] - centerx
            jy = node[edg1, 2] - centery
            jz = node[edg1, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[edg1, 1], node[edg1, 2], node[edg1, 3])) / 3
            SD[1, 1, 2, i, id] = edg1
            SD[1, 2, 2, i, id] = edg2
            SD[1, 3, 2, i, id] = a2
            SD[1, 4, 2, i, id] = f1

            SD[2, 3, 2, i, id] = edg1
            SD[2, 4, 2, i, id] = f2

            SD[3, 3, 2, i, id] = edg2
            SD[3, 4, 2, i, id] = f3
            SD[4, 4, 2, i, id] = area
            # SD[4,1,2,i,id]=v 
            #面3
            v1x = fcenter1x - node[edg1, 1]
            v1y = fcenter1y - node[edg1, 2]
            v1z = fcenter1z - node[edg1, 3]

            v2x = ccx - node[edg1, 1]
            v2y = ccy - node[edg1, 2]
            v2z = ccz - node[edg1, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5
            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg1, 1] - centerx
            jy = node[edg1, 2] - centery
            jz = node[edg1, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[edg1, 1], node[edg1, 2], node[edg1, 3])) / 3
            SD[1, 1, 3, i, id] = edg1
            SD[1, 2, 3, i, id] = face11
            SD[1, 3, 3, i, id] = N1
            SD[1, 4, 3, i, id] = f1

            SD[2, 2, 3, i, id] = face12
            SD[2, 3, 3, i, id] = N2
            SD[2, 4, 3, i, id] = f2

            SD[3, 2, 3, i, id] = face13
            SD[3, 3, 3, i, id] = N3
            SD[3, 4, 3, i, id] = f3

            SD[4, 3, 3, i, id] = N4
            SD[4, 4, 3, i, id] = area
            # SD[4,1,3,i,id]=v 
            #面4
            v1x = fcenter1x - node[edg2, 1]
            v1y = fcenter1y - node[edg2, 2]
            v1z = fcenter1z - node[edg2, 3]

            v2x = ccx - node[edg2, 1]
            v2y = ccy - node[edg2, 2]
            v2z = ccz - node[edg2, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5
            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg2, 1] - centerx
            jy = node[edg2, 2] - centery
            jz = node[edg2, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end

            v = v + area * (mydot(f1, f2, f3, node[edg2, 1], node[edg2, 2], node[edg2, 3])) / 3
            SD[1, 1, 4, i, id] = edg2
            SD[1, 2, 4, i, id] = face11
            SD[1, 3, 4, i, id] = N1
            SD[1, 4, 4, i, id] = f1

            SD[2, 2, 4, i, id] = face12
            SD[2, 3, 4, i, id] = N2
            SD[2, 4, 4, i, id] = f2

            SD[3, 2, 4, i, id] = face13
            SD[3, 3, 4, i, id] = N3
            SD[3, 4, 4, i, id] = f3

            SD[4, 3, 4, i, id] = N4
            SD[4, 4, 4, i, id] = area
            # SD[4,1,4,i,id]=v 
            #面5
            v1x = fcenter2x - node[edg1, 1]
            v1y = fcenter2y - node[edg1, 2]
            v1z = fcenter2z - node[edg1, 3]

            v2x = ccx - node[edg1, 1]
            v2y = ccy - node[edg1, 2]
            v2z = ccz - node[edg1, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5
            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg1, 1] - centerx
            jy = node[edg1, 2] - centery
            jz = node[edg1, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end

            v = v + area * (mydot(f1, f2, f3, node[edg1, 1], node[edg1, 2], node[edg1, 3])) / 3
            SD[1, 1, 5, i, id] = edg1
            SD[1, 2, 5, i, id] = face21
            SD[1, 3, 5, i, id] = N1
            SD[1, 4, 5, i, id] = f1

            SD[2, 2, 5, i, id] = face22
            SD[2, 3, 5, i, id] = N2
            SD[2, 4, 5, i, id] = f2

            SD[3, 2, 5, i, id] = face23
            SD[3, 3, 5, i, id] = N3
            SD[3, 4, 5, i, id] = f3

            SD[4, 3, 5, i, id] = N4
            SD[4, 4, 5, i, id] = area
            # SD[4,1,5,i,id]=v 
            #面6
            v1x = fcenter2x - node[edg2, 1]
            v1y = fcenter2y - node[edg2, 2]
            v1z = fcenter2z - node[edg2, 3]

            v2x = ccx - node[edg2, 1]
            v2y = ccy - node[edg2, 2]
            v2z = ccz - node[edg2, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5
            f1, f2, f3 = mynormalize(f1, f2, f3)

            jx = node[edg2, 1] - centerx
            jy = node[edg2, 2] - centery
            jz = node[edg2, 3] - centerz


            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end

            v = v + area * (mydot(f1, f2, f3, node[edg2, 1], node[edg2, 2], node[edg2, 3])) / 3
            SD[1, 1, 6, i, id] = edg2
            SD[1, 2, 6, i, id] = face21
            SD[1, 3, 6, i, id] = N1
            SD[1, 4, 6, i, id] = f1

            SD[2, 2, 6, i, id] = face22
            SD[2, 3, 6, i, id] = N2
            SD[2, 4, 6, i, id] = f2

            SD[3, 2, 6, i, id] = face23
            SD[3, 3, 6, i, id] = N3
            SD[3, 4, 6, i, id] = f3

            SD[4, 3, 6, i, id] = N4
            SD[4, 4, 6, i, id] = area
            SD[4, 1, 6, i, id] = v
        end

    end
    return nothing
end

function mycross(a, b, c, e, f, g)#计算叉乘
    return b * g - c * f, e * c - a * g, a * f - e * b
end

function mydot(a, b, c, e, f, g)
    return a * e + b * f + c * g
end

function mynorm(a, b, c)
    return (a^2 + b^2 + c^2)^0.5
end

function mynormalize(a, b, c)
    l = (a^2 + b^2 + c^2)^0.5
    return a / l, b / l, c / l
end

#😀 Cell-based smoothed domain
function GetCellNodeSD!(SD, element, node, nele)
    #=
    SD为保存的光滑域信息，5维矩阵，【4,4,k,m,n】  n为单元数量，m为每个单元的
    光滑域part部分，k为每个part所包含的面.
    =#
    ib = blockIdx().x
    it = (ib - 1) * blockDim().x + threadIdx().x
    if it > nele
        return nothing
    end
    stride = (gridDim().x) * blockDim().x

    for id in range(it, step = stride, nele)
        N1 = element[id, 1]
        N2 = element[id, 2]
        N3 = element[id, 3]
        N4 = element[id, 4]
        ccx = (node[N1, 1] + node[N2, 1] + node[N3, 1] + node[N4, 1]) / 4
        ccy = (node[N1, 2] + node[N2, 2] + node[N3, 2] + node[N4, 2]) / 4
        ccz = (node[N1, 3] + node[N2, 3] + node[N3, 3] + node[N4, 3]) / 4
        for i = 1:4
            v = 0
            if i == 1
                thenode = N1
                otherp1 = N2
                otherp2 = N3
                otherp3 = N4
            elseif i == 2
                thenode = N2
                otherp1 = N1
                otherp2 = N3
                otherp3 = N4
            elseif i == 3
                thenode = N3
                otherp1 = N1
                otherp2 = N2
                otherp3 = N4
            elseif i == 4
                thenode = N4
                otherp1 = N1
                otherp2 = N2
                otherp3 = N3
            end
            scx = (node[otherp1, 1] + node[otherp2, 1] + node[otherp3, 1] + ccx) / 4
            scy = (node[otherp1, 2] + node[otherp2, 2] + node[otherp3, 2] + ccy) / 4
            scz = (node[otherp1, 3] + node[otherp2, 3] + node[otherp3, 3] + ccz) / 4
            #面1
            jx = node[otherp1, 1] - scx
            jy = node[otherp1, 2] - scy
            jz = node[otherp1, 3] - scz

            v1x = node[otherp1, 1] - ccx
            v1y = node[otherp1, 2] - ccy
            v1z = node[otherp1, 3] - ccz

            v2x = node[otherp2, 1] - ccx
            v2y = node[otherp2, 2] - ccy
            v2z = node[otherp2, 3] - ccz

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5

            f1, f2, f3 = mynormalize(f1, f2, f3)

            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[otherp1, 1], node[otherp1, 2], node[otherp1, 3])) / 3

            SD[1, 1, 1, i, id] = otherp1

            SD[1, 2, 1, i, id] = otherp2

            SD[1, 3, 1, i, id] = N1
            SD[2, 3, 1, i, id] = N2
            SD[3, 3, 1, i, id] = N3
            SD[4, 3, 1, i, id] = N4

            SD[1, 4, 1, i, id] = f1
            SD[2, 4, 1, i, id] = f2
            SD[3, 4, 1, i, id] = f3
            SD[4, 4, 1, i, id] = area
            #面2

            jx = node[otherp2, 1] - scx
            jy = node[otherp2, 2] - scy
            jz = node[otherp2, 3] - scz

            v1x = node[otherp2, 1] - ccx
            v1y = node[otherp2, 2] - ccy
            v1z = node[otherp2, 3] - ccz

            v2x = node[otherp3, 1] - ccx
            v2y = node[otherp3, 2] - ccy
            v2z = node[otherp3, 3] - ccz

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5

            f1, f2, f3 = mynormalize(f1, f2, f3)

            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[otherp2, 1], node[otherp2, 2], node[otherp2, 3])) / 3

            SD[1, 1, 2, i, id] = otherp2

            SD[1, 2, 2, i, id] = otherp3

            SD[1, 3, 2, i, id] = N1
            SD[2, 3, 2, i, id] = N2
            SD[3, 3, 2, i, id] = N3
            SD[4, 3, 2, i, id] = N4

            SD[1, 4, 2, i, id] = f1
            SD[2, 4, 2, i, id] = f2
            SD[3, 4, 2, i, id] = f3
            SD[4, 4, 2, i, id] = area

            #面3

            jx = node[otherp3, 1] - scx
            jy = node[otherp3, 2] - scy
            jz = node[otherp3, 3] - scz

            v1x = node[otherp1, 1] - ccx
            v1y = node[otherp1, 2] - ccy
            v1z = node[otherp1, 3] - ccz

            v2x = node[otherp3, 1] - ccx
            v2y = node[otherp3, 2] - ccy
            v2z = node[otherp3, 3] - ccz

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5

            f1, f2, f3 = mynormalize(f1, f2, f3)

            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[otherp1, 1], node[otherp1, 2], node[otherp1, 3])) / 3

            SD[1, 1, 3, i, id] = otherp3

            SD[1, 2, 3, i, id] = otherp1

            SD[1, 3, 3, i, id] = N1
            SD[2, 3, 3, i, id] = N2
            SD[3, 3, 3, i, id] = N3
            SD[4, 3, 3, i, id] = N4

            SD[1, 4, 3, i, id] = f1
            SD[2, 4, 3, i, id] = f2
            SD[3, 4, 3, i, id] = f3
            SD[4, 4, 3, i, id] = area

            #面4
            jx = node[otherp1, 1] - scx
            jy = node[otherp1, 2] - scy
            jz = node[otherp1, 3] - scz

            v1x = node[otherp2, 1] - node[otherp1, 1]
            v1y = node[otherp2, 2] - node[otherp1, 2]
            v1z = node[otherp2, 3] - node[otherp1, 3]

            v2x = node[otherp3, 1] - node[otherp1, 1]
            v2y = node[otherp3, 2] - node[otherp1, 2]
            v2z = node[otherp3, 3] - node[otherp1, 3]

            f1, f2, f3 = mycross(v1x, v1y, v1z, v2x, v2y, v2z)
            area = mynorm(f1, f2, f3) * 0.5

            f1, f2, f3 = mynormalize(f1, f2, f3)

            if mydot(f1, f2, f3, jx, jy, jz) < 0
                f1 = -f1
                f2 = -f2
                f3 = -f3
            end
            v = v + area * (mydot(f1, f2, f3, node[otherp1, 1], node[otherp1, 2], node[otherp1, 3])) / 3

            SD[1, 1, 4, i, id] = otherp1
            SD[4, 1, 4, i, id] = v

            SD[1, 2, 4, i, id] = otherp2

            SD[1, 3, 4, i, id] = otherp3

            SD[1, 4, 4, i, id] = f1
            SD[2, 4, 4, i, id] = f2
            SD[3, 4, 4, i, id] = f3
            SD[4, 4, 4, i, id] = area

        end

    end
    return nothing
end

function GetSDofNode(node, element)
    # element=sort(element,dims=2)
    N = size(element, 1)
    numblocks = ceil(Int, N / 256)
    SD_GPU = CuArray(zeros(4, 4, 4, 4, size(element, 1)))
    element_GPU = CuArray(element)
    node_GPU = CuArray(node)
    # @cuda threads=256 blocks=numblocks 
    @cuda threads = 256 blocks = numblocks GetCellNodeSD!(SD_GPU, element_GPU, node_GPU, N)
    synchronize()
    return Array(SD_GPU)
end


#😊 Cell-based SD stiffness calculation
function GetCellSDMatrix(SD, ele, MAT, MATID)
    #仅计算一个part，不能计算多体
    println("体光滑域计算中...")

    nele = size(SD, 5) * 4
    numofmatrix = 16

    IKV, JKV, VKV = SharedVector{Int32}(numofmatrix * nele), SharedVector{Int32}(numofmatrix * nele), SharedVector{Float64}(numofmatrix * nele)

    IKT, JKT, VKT = SharedVector{Int32}(numofmatrix * nele), SharedVector{Int32}(numofmatrix * nele), SharedVector{Float64}(numofmatrix * nele)

    HD = SharedArray(zeros(Float64, 3, 4, 4, size(SD, 5)))

    SD = SharedArray(SD)

    ele = SharedArray(ele)

    GetCellSDMatrix2!(HD, SD, MAT, MATID, IKV, JKV, VKV, IKT, JKT, VKT, ele)

    # return IKV,JKV,VKV,IKT,JKT,VKT
    return sparse(IKV, JKV, VKV), sparse(IKT, JKT, VKT), HD

end

function GetCellSDMatrix2!(HD, SD, MAT, MATID, IKV, JKV, VKV, IKT, JKT, VKT, ele)

    @inbounds @sync @distributed for i = 1:size(SD, 5)
        for j = 1:4
            for k = 1:4
                for c = 1:3

                    m = 0
                    for r = 1:4
                        if SD[r, c, k, j, i] != 0
                            m = m + 1
                        end
                    end

                    if k == 4
                        if c == 1
                            m = m - 1
                        end
                    end

                    for r = 1:m
                        nodeid = findfirst(x -> x == SD[r, c, k, j, i], ele[i, :])
                        # @show SD[r,c,k,j,i]
                        # @show ele[i,:]
                        HD[:, nodeid, j, i] += ((1 / 3) / m) * SD[4, 4, k, j, i] * SD[1:3, 4, k, j, i]
                    end
                end
            end

            HH = HD[:, :, j, i]

            C = MAT[MATID[i], :]

            λ = C[1] #热导率

            ϵ = C[2] #电导率

            KV = (HH' * ϵ * HH) / SD[4, 1, 4, j, i]

            KT = (HH' * λ * HH) / SD[4, 1, 4, j, i]

            dof = ele[i, :]

            start = (4 * (i - 1) + j - 1) * 16

            AssembleIJK!(KV, dof, IKV, JKV, VKV, start)

            AssembleIJK!(KT, dof, IKT, JKT, VKT, start)
        end

    end
end

#😊 施加固定电压
function AddEssBdy_Vol(K, F, BDY, value) # 施加本质边界条件，电压
    DOF = unique(BDY[:])
    for i = 1:size(DOF, 1)
        a = Int64(DOF[i, 1])
        K[a, :] .= 0
        K[a, a] = 1
        F[a] = value
    end
    return K, F
end

#😊 荷载计算电流边界
function CurFlowBoundary(node, bdy, qb)
    n = size(node, 1)
    F = zeros(n)
    for i = 1:size(bdy, 1)
        a = bdy[i, :]
        DOF = a
        col = node[a, :]
        the_fh = CurFlowBoundary1(col, qb)
        F[DOF] += the_fh
    end
    return F
end

function CurFlowBoundary1(p, qb)
    #坐标到2D
    p[2, :] = p[2, :] - p[1, :]
    p[3, :] = p[3, :] - p[1, :]
    p[4, :] = p[4, :] - p[1, :]
    fx = normalize(p[2, :])
    fy = normalize(cross(cross(fx, p[3, :]), fx))
    pp = zeros(4, 2)
    for i = 2:4
        pp[i, :] = [dot(p[i, :], fx), dot(p[i, :], fy)]
    end
    #开始
    r = s = [0.577350269189626, -0.577350269189626]
    F = zeros(4)
    for i in r
        for j in s
            B = CurFlowBoundary2(pp, qb, i, j)
            F += B
        end
    end
    return F
end

function CurFlowBoundary2(col, qb, r, s)
    H = [0.25 * (1 - r) * (1 - s), 0.25 * (1 + r) * (1 - s), 0.25 * (1 + r) * (1 + s), 0.25 * (1 - r) * (1 + s)]
    Hd = [s-1 1-s s+1 -1-s
        r-1 -1-r r+1 1-r] * 0.25
    J = zeros(2, 2)
    x = col[:, 1]
    y = col[:, 2]
    J[1, 1] = x' * Hd[1, :]
    J[1, 2] = y' * Hd[1, :]
    J[2, 1] = x' * Hd[2, :]
    J[2, 2] = y' * Hd[2, :]
    DJ = abs(det(J))
    #计算当前换热系数
    F = H * qb * DJ
    return F
end

#😊 对流换热
function HcBoundary(node, bdy, h, ue)
    n = size(node, 1)
    IK = Vector{Int64}()
    JK = Vector{Int64}()
    VK = Vector{Float64}()
    F = zeros(n)
    for i = 1:size(bdy, 1)
        a = bdy[i, :]
        col = node[a, :]
        the_kh, the_fh = GetStiffnessHc1(col, h, ue)
        IK, JK, VK = AssembleIJK(IK, JK, VK, the_kh, a)
        for j = 1:length(a)
            F[a[j]] += the_fh[j]
        end
    end
    return IK, JK, VK, F
end

function GetStiffnessHc1(p, fh, ue)
    #坐标到2D
    p[2, :] = p[2, :] - p[1, :]
    p[3, :] = p[3, :] - p[1, :]
    p[4, :] = p[4, :] - p[1, :]
    fx = normalize(p[2, :])
    fy = normalize(cross(cross(fx, p[3, :]), fx))
    pp = zeros(4, 2)
    for i = 2:4
        pp[i, :] = [dot(p[i, :], fx), dot(p[i, :], fy)]
    end
    #开始
    r = s = [0.577350269189626, -0.577350269189626]
    K = zeros(4, 4)
    F = zeros(4)
    for i in r
        for j in s
            A, B = GetStiffnessHc2(pp, fh, ue, i, j)
            K += A
            F += B
        end
    end
    return K, F
end

function GetStiffnessHc2(col, fh, ue, r, s)
    H = [0.25 * (1 - r) * (1 - s), 0.25 * (1 + r) * (1 - s), 0.25 * (1 + r) * (1 + s), 0.25 * (1 - r) * (1 + s)]
    Hd = [s-1 1-s s+1 -1-s
        r-1 -1-r r+1 1-r] * 0.25
    J = zeros(2, 2)
    x = col[:, 1]
    y = col[:, 2]
    J[1, 1] = x' * Hd[1, :]
    J[1, 2] = y' * Hd[1, :]
    J[2, 1] = x' * Hd[2, :]
    J[2, 2] = y' * Hd[2, :]
    DJ = abs(det(J))

    K = H * fh * (H') * DJ

    F = H * fh * (ue) * DJ

    return K, F

end

function AddIJVK(K, IK, JK, VK)
    for i = 1:length(IK)
        K[IK[i], JK[i]] += VK[i]
    end
    return K
end

#😊 计算焦耳热
function GetJoulSource(node, element, HD, SD, u, MAT, MATID)
    QJ = zeros(size(node, 1))

    for i = 1:size(element, 1)
        uele = u[element[i, :]]
        h = zeros(4)
        C = MAT[MATID[i], :]
        for j = 1:4
            dof = setdiff(1:4, j)
            v = SD[4, 1, 4, j, i]
            B = HD[:, :, j, i] / v
            E = B * uele



            qj = dot(E, C[2] * E)

            ih = v / 4

            h[dof[1]] += ih[1] * 1.25 * qj
            h[dof[2]] += ih[1] * 1.25 * qj
            h[dof[3]] += ih[1] * 1.25 * qj
            h[j] += ih[1] * 0.25 * qj
        end

        a = element[i, :]
        for k = 1:4
            QJ[a[k]] += h[k]
        end
    end

    return QJ
end

#😊 solve
function Solve(KE, Q, num)
    ps = MKLPardisoSolver()
    set_nprocs!(ps, num)
    result = similar(Q)
    result = solve(ps, KE, Q)
end

#😊 write result
function writeResulttovtk_TET(node, element; r = [], name = "undefine", des = "undefine")
    cells = MeshCell[]
    for i = 1:size(element, 1)
        a = MeshCell(VTKCellType(10), element[i, :])
        push!(cells, a)
    end
    vtkfile = vtk_grid(name, node[:, 1], node[:, 2], node[:, 3], cells)
    if !isempty(r)
        vtkfile[des, VTKPointData()] = r
    end
    outfiles = vtk_save(vtkfile)
end

end

##