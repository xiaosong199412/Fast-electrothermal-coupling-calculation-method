using LinearAlgebra

function Getelemat2(ele)
    gpx = gpy = gpz = [0.577350269189626,-0.577350269189626]
    F=zeros(8)
    for i = 1:2
        for j = 1:2
            for k = 1:2
                A= Getelemat3(gpx[i], gpy[j], gpz[k], ele)
                F+=A
            end
        end
    end
    return F
end

function Getelemat3(r, s, t, ele)
    # 形函数 h(r,s,t)=0.125*[(1-r)*(1-s)*(1-t) (1+r)*(1-s)*(1-t) (1+r)*(1+s)*(1-t) (1-r)*(1+s)*(1-t) (1-r)*(1-s)*(1+t) (1+r)*(1-s)*(1+t) (1+r)*(1+s)*(1+t) (1-r)*(1+s)*(1+t)];
    hdr = [-((s - 1) * (t - 1)) / 8, ((s - 1) * (t - 1)) / 8, -((s + 1) * (t - 1)) / 8, ((s + 1) * (t - 1)) / 8, ((s - 1) * (t + 1)) / 8,-((s - 1) * (t + 1)) / 8, ((s + 1) * (t + 1)) / 8, -((s + 1) * (t + 1)) / 8]
    hds = [-((r - 1) * (t - 1)) / 8, ((r + 1) * (t - 1)) / 8, -((r + 1) * (t - 1)) / 8, ((r - 1) * (t - 1)) / 8, ((r - 1) * (t + 1)) / 8, -((r + 1) * (t + 1)) / 8, ((r + 1) * (t + 1)) / 8, -((r - 1) * (t + 1)) / 8]
    hdt = [-((r - 1) * (s - 1)) / 8, ((r + 1) * (s - 1)) / 8, -((r + 1) * (s + 1)) / 8, ((r - 1) * (s + 1)) / 8, ((r - 1) * (s - 1)) / 8, -((r + 1) * (s - 1)) / 8, ((r + 1) * (s + 1)) / 8, -((r - 1) * (s + 1)) / 8]
    h=0.125*[(1-r)*(1-s)*(1-t),(1+r)*(1-s)*(1-t),(1+r)*(1+s)*(1-t),(1-r)*(1+s)*(1-t),(1-r)*(1-s)*(1+t),(1+r)*(1-s)*(1+t),(1+r)*(1+s)*(1+t),(1-r)*(1+s)*(1+t)];
    ##雅可比矩阵
    J = zeros(3, 3)
    J[1,1] = (ele[:,1]') * hdr
    J[1,2] = (ele[:,2]') * hdr
    J[1,3] = (ele[:,3]') * hdr

    J[2,1] = (ele[:,1]') * hds
    J[2,2] = (ele[:,2]') * hds
    J[2,3] = (ele[:,3]') * hds

    J[3,1] = (ele[:,1]') * hdt
    J[3,2] = (ele[:,2]') * hdt
    J[3,3] = (ele[:,3]') * hdt
    DJ = abs(det(J))
    

    

    # 材料矩阵

    return h*DJ
end

col=node[element[1,[1,2,3,5]],:]
# col=[0 0 0;1 0 0;1 1 0;0 1 0;0 0 1;1 0 1;1 1 1;0 1 2]
v=(1/6)*abs(det([col ones(4)]))

col=col[[1,2,3,3,4,4,4,4],:]

a=Getelemat2(col)
b=sum(a[5:8])
v/4
##
function shapeTet(col)
    v=(1/6)*abs(det([col ones(4)]))
    return v*ones(4)*0.25
end

shapeTet(col)
for i=1:size(element,1)
    col=node[element[i,[1,2,3,5]],:]
    # col=[0 0 0;1 0 0;1 1 0;0 1 0;0 0 1;1 0 1;1 1 1;0 1 2]
    v=(1/6)*abs(det([col ones(4)]))

    col=col[[1,2,3,3,4,4,4,4],:]

    a=Getelemat2(col)
    b=sum(a[5:8])
    c=sum(a[3:4])
    duijiao=v/4
    if abs(a[1]-duijiao)<1e-7 || abs(a[2]-duijiao)<1e-7 || abs(b-duijiao)<1e-7 || abs(c-duijiao)<1e-7 
        # println("正确")
    else
        println("$(i) 单元不对")
    end


end
##
col=node[element[1,[1,2,3,5]],:]
cen=(sum(col,dims=1)/size(col,1))
h=zeros(4)
for j=1:4
    dof=setdiff(1:4,j)
    tet=[col[setdiff(1:4,j),:];cen]
    # T=zeros(4,4)
    # T[end,:].=0.25
    # T[1,dof[1]]=1
    # T[2,dof[2]]=1
    # T[3,dof[3]]=1
    ih=shapeTet(tet)
    h[dof[1]]+=ih[1]*1.25
    h[dof[2]]+=ih[1]*1.25
    h[dof[3]]+=ih[1]*1.25
    h[j]+=ih[1]*0.25

end