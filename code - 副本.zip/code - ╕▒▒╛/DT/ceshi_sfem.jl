using DelimitedFiles, WriteVTK ,BenchmarkTools
push!(LOAD_PATH,"./module")
using DT_bushing
using Distributed
addprocs(15)
@everywhere push!(LOAD_PATH,"./module")
@everywhere using FOSFEM,LinearAlgebra
function Readdata(position)
    a = readlines(string(position, "/ds.dat"))
    nstart = 0
    nend = 0
    element = []
    BDY = []
    BDY2 = []
    for i = 1:length(a)
        b = a[i]
        if length(b) >= 7
            if b[1:6] == "nblock"
                nstart = i
                for j = nstart:length(a)
                    if a[j] == "-1"
                        nend = j
                        break
                    end
                end
                nstart += 2
                nend -= 1
            end
            # 本质边界
            # if b[1:7] == "CMBLOCK"
            #     bb = []
            #     for j = (i + 2):length(a)
            #         if a[j][1:4] == "/com"
            #             break
            #         end 
            #         push!(bb, a[j])
            #     end
            #     push!(BDY2, bb)
            # end



            # 单元和自然边界
            if b[1:6] == "eblock"
                if occursin("solid", a[i])
                    for j = (i+2):length(a)
                        if a[j] == "-1"
                            break
                        end
                        push!(element, a[j])
                    end
                else
                    bb = []
                    for j = (i+2):length(a)
                        if a[j] == "-1"
                            break
                        end
                        push!(bb, a[j])
                    end
                    push!(BDY, bb)
                end
            end
        end
    end


    node = a[nstart:nend]

    writedlm(string(position, "/node.txt"), node)
    writedlm(string(position, "/element.txt"), element)

    for i = 1:length(BDY)
        writedlm(string(position, "/BDYZR$(i).txt"), BDY[i])
    end


    for i = 1:length(BDY2)
        writedlm(string(position, "/BDYBZ$(i).txt"), BDY2[i])
    end


end

function writegridHex(node, element, name::String)
    cells = MeshCell[]
    for i = 1:size(element, 1)
        a = MeshCell(VTKCellType(12), element[i, :])
        push!(cells, a)
    end
    vtkfile = vtk_grid(name, node[:, 1], node[:, 2], node[:, 3], cells)
    outfiles = vtk_save(vtkfile)
end
##
pos = "./data/172w"
Readdata(pos)

# writegridHex(node, element,"dsd")
#
node = readdlm(string(pos, "/node.txt"), Float64)[:, 2:4]
element=readdlm(string(pos,"/element.txt"),Int64)[:,[12,13,15,18]]
MATID=readdlm(string(pos,"/element.txt"),Int64)[:,1]
BDY1 = readdlm(string(pos, "/BDYZR1.txt"), Int64)[:, 6:9]
BDY2 = readdlm(string(pos, "/BDYZR2.txt"), Int64)[:, 6:9]
BDY3 = readdlm(string(pos, "/BDYZR3.txt"), Int64)[:, 6:9]
BDY4 = readdlm(string(pos, "/BDYZR4.txt"), Int64)[:, 6:9]
BDY5 = readdlm(string(pos, "/BDYZR5.txt"), Int64)[:, 6:9]

# 材料
sf6 = [0.002 1e-16 21.35 665.18]
al = [237 35.5e6 2770 880]
xj = [200 1e-16 3000 500]
hysz = [2 1e-16 3100 550]
cu = [400 5.998e7 7900 470]
MAT = [cu; hysz; xj; xj; al; al; al; sf6; sf6]
##生成光滑域
SD=FOSFEM.GetSDofNode(node,element);

##求解电场
@btime KV,KT,HD=FOSFEM.GetCellSDMatrix(SD,element,MAT,MATID);

function Mysolve(KV,KT,HD,num)
    qb = 3000 / (14395e-6)

    Fcur1 = FOSFEM.CurFlowBoundary(node, BDY3, qb)

    Fcur2 = FOSFEM.CurFlowBoundary(node, BDY4, -qb)

    FG = Fcur1 + Fcur2

    KG, FG = FOSFEM.AddEssBdy_Vol(KV, FG, BDY1,110000)
    KG, FG = FOSFEM.AddEssBdy_Vol(KG, FG, BDY2,0)

    V=FOSFEM.Solve(KG,FG,num)

    println("电场计算完成")
    # FJ = DT_bushing.TGetelemat(node, element, MAT, V)
    FJ = FOSFEM.GetJoulSource(node,element,HD,SD,V,MAT,MATID)
    h, ue = 1, 22
    IK, JK, VK, FC = FOSFEM.HcBoundary(node, BDY5, h, ue)

    KT = DT_bushing.AddIJVK(KT, IK, JK, VK)

    FT = FJ + FC

    TT= FOSFEM.Solve(KT,FT,num)
    return V,TT
end

num=16;
KVV=KV[:,:];
KTT=KT[:,:];
@btime V,T=Mysolve(KVV,KTT,HD,num);

maximum(T)
# 求解温度场

#本质边界
# DOFT1 = unique(BDY5[:])
# BZ1 = zeros(size(DOFT1, 1), 2)
# BZ1[:, 1] = DOFT1
# BZ1[:, 2] .= 60

# KT1,FT1=AddEssBdy(KT,FT,BZ1)
##TIDU
function GetGradient(node,element,re)
    nn=size(node,1)
    Elegra=Vector{Any}(nothing,nn)
    for i=1:size(element,1)
        dof=element[i,:]
        the_re=re[dof]
        the_col=node[dof,:]
        
        the_col[2,:]=the_col[2,:]-the_col[1,:]
        the_col[3,:]=the_col[3,:]-the_col[1,:]
        the_col[4,:]=the_col[4,:]-the_col[1,:]
        the_col[1,:].=0
        #[1,x,y,z]
        A=ones(4,4)
        A[:,2:4]=the_col
        a=A\the_re
        v=abs(det(A))/6
        b=[a[2:4];v]
        for j=1:4
            isnothing(Elegra[j]) ? Elegra[j]=b : Elegra[j]=[Elegra[j] b]
        end
    end
    out=zeros(nn,3)
    
    for i = 1:length(Elegra)
        p=Elegra[i]
        w=p[end,:]/sum(p[end,:])
        g=p[1:3,:]*w
        out[i,:]=g
    end
    return out
end

Elegra=GetGradient(node,element,V)

##

FOSFEM.writeResulttovtk_TET(node, element,r=T,name="$(size(element,1)) SFEM",des="T")