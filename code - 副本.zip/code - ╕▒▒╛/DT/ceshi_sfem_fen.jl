using DelimitedFiles, WriteVTK ,BenchmarkTools
push!(LOAD_PATH,"./module")
using DT_bushing
using Distributed
# addprocs()
@everywhere push!(LOAD_PATH,"./module")
@everywhere using FOSFEM,LinearAlgebra
function Readdata(position)
    a = readlines(string(position, "/ds.dat"))
    nstart = 0
    nend = 0
    element = []
    BDY = []
    BDY2 = []
    for i = 1:length(a)
        b = a[i]
        if length(b) >= 7
            if b[1:6] == "nblock"
                nstart = i
                for j = nstart:length(a)
                    if a[j] == "-1"
                        nend = j
                        break
                    end
                end
                nstart += 2
                nend -= 1
            end
            # 本质边界
            # if b[1:7] == "CMBLOCK"
            #     bb = []
            #     for j = (i + 2):length(a)
            #         if a[j][1:4] == "/com"
            #             break
            #         end 
            #         push!(bb, a[j])
            #     end
            #     push!(BDY2, bb)
            # end



            # 单元和自然边界
            if b[1:6] == "eblock"
                if occursin("solid", a[i])
                    for j = (i+2):length(a)
                        if a[j] == "-1"
                            break
                        end
                        push!(element, a[j])
                    end
                else
                    bb = []
                    for j = (i+2):length(a)
                        if a[j] == "-1"
                            break
                        end
                        push!(bb, a[j])
                    end
                    push!(BDY, bb)
                end
            end
        end
    end


    node = a[nstart:nend]

    writedlm(string(position, "/node.txt"), node)
    writedlm(string(position, "/element.txt"), element)

    for i = 1:length(BDY)
        writedlm(string(position, "/BDYZR$(i).txt"), BDY[i])
    end


    for i = 1:length(BDY2)
        writedlm(string(position, "/BDYBZ$(i).txt"), BDY2[i])
    end


end

function writegridHex(node, element, name::String)
    cells = MeshCell[]
    for i = 1:size(element, 1)
        a = MeshCell(VTKCellType(12), element[i, :])
        push!(cells, a)
    end
    vtkfile = vtk_grid(name, node[:, 1], node[:, 2], node[:, 3], cells)
    outfiles = vtk_save(vtkfile)
end

pos = "./data/89w"
Readdata(pos)

# writegridHex(node, element,"dsd")
#
node = readdlm(string(pos, "/node.txt"), Float64)[:, 2:4]
element=readdlm(string(pos,"/element.txt"),Int64)[:,[12,13,15,18]]
MATID=readdlm(string(pos,"/element.txt"),Int64)[:,1]
BDY1 = readdlm(string(pos, "/BDYZR1.txt"), Int64)[:, 6:9]
BDY2 = readdlm(string(pos, "/BDYZR2.txt"), Int64)[:, 6:9]
BDY3 = readdlm(string(pos, "/BDYZR3.txt"), Int64)[:, 6:9]
BDY4 = readdlm(string(pos, "/BDYZR4.txt"), Int64)[:, 6:9]
BDY5 = readdlm(string(pos, "/BDYZR5.txt"), Int64)[:, 6:9]

# 材料
sf6 = [0.002 1e-16 21.35 665.18]
al = [237 35.5e6 2770 880]
xj = [200 1e-16 3000 500]
hysz = [2 1e-16 3100 550]
cu = [400 5.998e7 7900 470]
MAT = [cu; hysz; xj; xj; al; al; al; sf6; sf6]
##生成光滑域
SD=FOSFEM.GetSDofNode(node,element);

##求解电场

@btime KV,KT,HD=FOSFEM.GetCellSDMatrix(SD,element,MAT,MATID);

##
qb = 3000 / (14395e-6)
DOFU1 = unique(BDY1[:])

BZ1 = zeros(size(DOFU1, 1), 2)

BZ1[:, 1] = DOFU1
BZ1[:, 2] .= 110000

DOFU2 = unique(BDY2[:])

BZ2 = zeros(size(DOFU2, 1), 2)

BZ2[:, 1] = DOFU2

BZ = [BZ1; BZ2]

Fcur1 = DT_bushing.CurFlowBoundary(node, BDY3, qb)

Fcur2 = DT_bushing.CurFlowBoundary(node, BDY4, -qb)

FG = Fcur1 + Fcur2

KG, FG = DT_bushing.AddEssBdy(KV, FG, BZ)

V=FOSFEM.Solve(KG,FG,num)

println("电场计算完成")
# FJ = DT_bushing.TGetelemat(node, element, MAT, V)

## 焦耳热计算时间
@btime FJ = FOSFEM.GetJoulSource(node,element,HD,SD,V,MAT,MATID);
@btime FJ2 = DT_bushing.TGetelemat(node, element, MAT, V);
maximum(abs.(FJ-FJ2))
##
h, ue = 1, 22
IK, JK, VK, FC = DT_bushing.HcBoundary(node, BDY5, h, ue)

KT = DT_bushing.AddIJVK(KT, IK, JK, VK)

FT = FJ + FC

TT= FOSFEM.Solve(KT,FT,num)

##


num=16;
KVV=KV[:,:];
KTT=KT[:,:];
@btime V,T=Mysolve(KVV,KTT,HD,num);

maximum(T)
# 求解温度场

#本质边界
# DOFT1 = unique(BDY5[:])
# BZ1 = zeros(size(DOFT1, 1), 2)
# BZ1[:, 1] = DOFT1
# BZ1[:, 2] .= 60

# KT1,FT1=AddEssBdy(KT,FT,BZ1)




##

FOSFEM.writeResulttovtk_TET(node, element,r=T,name="$(size(element,1)) SFEM",des="T")