module ReadAnsys

using DelimitedFiles

export  Readdata

function Readdata(position)
    a = readlines(string(position,"/ds.dat"))
    nstart = 0
    nend = 0
    element = []
    BDY = []
    BDY2 = []
    for i = 1:length(a)
        b = a[i]
        if length(b) >= 7
            if b[1:6] == "nblock"
                nstart = i
                for j = nstart:length(a)
                    if a[j] == "-1"
                        nend = j
                        break
                    end
                end
                nstart += 2
                nend -= 1
            end
            #本质边界
            if b[1:7]=="CMBLOCK"
                bb=[]
                for j =(i+2):length(a)
                    if a[j][1:4] == "/com"
                        break
                    end 
                    push!(bb,a[j])
                end
                push!(BDY2,bb)
            end



            #单元和自然边界
            if b[1:6] == "eblock"
                if occursin("solid", a[i])
                    for j = (i + 2):length(a)
                        if a[j] == "-1"
                            break
                        end
                        push!(element, a[j])
                    end
                else
                    bb = []
                    for j = (i + 2):length(a)
                        if a[j] == "-1"
                            break
                        end
                        push!(bb, a[j])
                    end
                    push!(BDY, bb)
                end
            end
        end
    end


    node = a[nstart:nend]

    writedlm(string(position,"/node.txt"),node)
    writedlm(string(position,"/element.txt"),element)

    for i = 1:length(BDY)
        writedlm(string(position,"/BDYZR$(i).txt"), BDY[i])
    end


    for i = 1:length(BDY2)
        writedlm(string(position,"/BDYBZ$(i).txt"), BDY2[i])
    end


end

end