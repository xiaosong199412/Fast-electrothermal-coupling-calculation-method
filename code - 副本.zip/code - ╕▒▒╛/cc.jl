function aa(x)
    x+x
end

cc=@btime aa(1);