using LinearAlgebra,Plots
node=[0 0 0
1 0 0
0 1 0
0 0 1]
tri=[1 2 3;1 2 4;1 3 4;2 3 4]

function Areatri(thecol,center)
    v1=thecol[2,:]-thecol[1,:]
    v2=thecol[3,:]-thecol[1,:]
    fn=cross(v1,v2)
    area=norm(fn)*0.5
    jy=thecol[1,:]-center
    if dot(jy,fn)<0
        fn=-fn
    end
    fn=normalize(fn)
    return area,fn
end

S=[]
FN=[]
center=(sum(node,dims=1)/4)[:]
for i=1:size(tri,1)
    thecol=node[tri[i,:],:]
    s,fn=Areatri(thecol,center)
    push!(S,s)
    push!(FN,fn)
end
##
A=[ones(4) node]
V=det(A)/6
##
H=[1/3 1/3 1/3 0;
1/3 1/3 0 1/3;
1/3 0 1/3 1/3;
0 1/3 1/3 1/3]
##
B=zeros(4,3)
for i=1:4
    B+=H[i,:]*FN[i]'*S[i]
end

##

B=B/V